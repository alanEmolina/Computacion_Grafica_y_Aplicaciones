#Instalar libreria por consola
#!pip install PyQt5
import sys
from PyQt5 import QtGui, QtWidgets, uic
from PyQt5.QtCore import pyqtSlot, Qt
from PyQt5 import QtOpenGL
from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *
from figuras import *

# Ventana Clase OpenGL
class Viewer3DWidget(QtOpenGL.QGLWidget):
    max_xyz = 2.0

    def __init__(self, parent=None):
        super(Viewer3DWidget, self).__init__(parent)
        """declarar los angulos iniciales (3)"""

    # Funciones protegidas OpenGL
    def paintGL(self):
        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glEnable(GL_DEPTH_TEST)
        self.dibujar()
        glFlush()

    def resizeGL(self, widthInPixels, heightInPixels):
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        aspect_ratio = widthInPixels / heightInPixels
        if widthInPixels <= heightInPixels:
            glOrtho(-self.max_xyz * aspect_ratio, self.max_xyz * aspect_ratio, -self.max_xyz, self.max_xyz, -self.max_xyz, self.max_xyz)
        else:
            glOrtho(-self.max_xyz, self.max_xyz, -self.max_xyz / aspect_ratio, self.max_xyz / aspect_ratio, -self.max_xyz, self.max_xyz)
        glViewport(0, 0, widthInPixels, heightInPixels)


    def initializeGL(self):
        glClearColor(0.0, 0.0, 0.0, 1.0)
        glClearDepth(1.0)

    # Métodos-Seleccion-Figuras
    def dibujar(self):
        """funcion de rotacion x3 una para cada rotacion tendra asignado un angulo"""



        cubo()

# Ventana principal
class Ventana(QtWidgets.QMainWindow):
    def __init__(self):
        super(Ventana, self).__init__()
        self.ui = uic.loadUi('Main.ui', self)
        self.ui.setWindowIcon(QtGui.QIcon('uoh.jpg'))
        self.ui.setWindowFlags(Qt.WindowCloseButtonHint | Qt.WindowMinimizeButtonHint)

        # Verificar que el widget 'widget' existe en el archivo UI
        if hasattr(self.ui, 'widget'):
            layout = QtWidgets.QVBoxLayout(self.ui.widget)  # Usar un layout
            self.viewer3D = Viewer3DWidget(self)
            layout.addWidget(self.viewer3D)  # Añadir viewer3D al layout
        else:
            raise AttributeError("El archivo Main.ui no contiene un widget llamado 'widget'")

        self.ui.show()

        # Verificar la existencia de los sliders
        if not (hasattr(self.ui, 'ejex') and hasattr(self.ui, 'ejey') and hasattr(self.ui, 'ejez')):
            raise AttributeError("El archivo Main.ui debe contener los sliders 'ejex', 'ejey', y 'ejez'")
        
        # Asegurarse de que los sliders son del tipo correcto
        print(f"rotarx: {type(self.ui.ejex)}, rotary: {type(self.ui.ejey)}, rotarz: {type(self.ui.ejez)}")
        if not (isinstance(self.ui.ejex, QtWidgets.QSlider) and 
                isinstance(self.ui.ejey, QtWidgets.QSlider) and 
                isinstance(self.ui.ejez, QtWidgets.QSlider)):
            raise TypeError("Los widgets 'rotarx', 'rotary', y 'rotarz' deben ser del tipo QSlider")

        # Signals
        self.ui."""nombre del primer QSlider""".valueChanged.connect("""nombre de la funcion asociada""")
        self.ui."""nombre del segundo QSlider""".valueChanged.connect("""nombre de la funcion asociada""")
        self.ui."""nombre del tercero QSlider""".valueChanged.connect("""nombre de la funcion asociada""")

    # Slots
    @pyqtSlot()
    def rotarx(self):
        """definir como se debe realizar la rotacion en eje x"""

    @pyqtSlot()
    def rotary(self):
        """definir como se debe realizar la rotacion en eje y"""

    @pyqtSlot()
    def rotarz(self):
        """definir como se debe realizar la rotacion en eje z"""

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    ventana = Ventana()
    sys.exit(app.exec_())
