#instalar librerias por consola
#!pip install PyOpenGL
from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *

def cubo(escala=1.0):
    # Cuadrado 1
    glBegin(GL_QUADS)
    glColor3f(1, 0, 0)
    glVertex3f(-1 * escala, -1 * escala, 1 * escala)
    glVertex3f(1 * escala, -1 * escala, 1 * escala)
    glVertex3f(1 * escala, 1 * escala, 1 * escala)
    glVertex3f(-1 * escala, 1 * escala, 1 * escala)
    glEnd()
    # Cuadrado 2
    glBegin(GL_QUADS)
    glColor3f(0, 1, 0)
    glVertex3f(-1 * escala, -1 * escala, -1 * escala)
    glVertex3f(1 * escala, -1 * escala, -1 * escala)
    glVertex3f(1 * escala, 1 * escala, -1 * escala)
    glVertex3f(-1 * escala, 1 * escala, -1 * escala)
    glEnd()
    # Cuadrado 3
    glBegin(GL_QUADS)
    glColor3f(0, 0, 1)
    glVertex3f(1 * escala, 1 * escala, 1 * escala)
    glVertex3f(1 * escala, -1 * escala, 1 * escala)
    glVertex3f(1 * escala, -1 * escala, -1 * escala)
    glVertex3f(1 * escala, 1 * escala, -1 * escala)
    glEnd()
    # Cuadrado 4
    glBegin(GL_QUADS)
    glColor3f(1, 1, 0)
    glVertex3f(-1 * escala, 1 * escala, 1 * escala)
    glVertex3f(1 * escala, 1 * escala, 1 * escala)
    glVertex3f(1 * escala, 1 * escala, -1 * escala)
    glVertex3f(-1 * escala, 1 * escala, -1 * escala)
    glEnd()
    # Cuadrado 5
    glBegin(GL_QUADS)
    glColor3f(0, 1, 1)
    glVertex3f(-1 * escala, 1 * escala, 1 * escala)
    glVertex3f(-1 * escala, -1 * escala, 1 * escala)
    glVertex3f(-1 * escala, -1 * escala, -1 * escala)
    glVertex3f(-1 * escala, 1 * escala, -1 * escala)
    glEnd()
    # Cuadrado 6
    glBegin(GL_QUADS)
    glColor3f(1, 0, 1)
    glVertex3f(-1 * escala, -1 * escala, 1 * escala)
    glVertex3f(1 * escala, -1 * escala, 1 * escala)
    glVertex3f(1 * escala, -1 * escala, -1 * escala)
    glVertex3f(-1 * escala, -1 * escala, -1 * escala)
    glEnd()