## Ejercicio fácil 1 ##

x=int(input("Ingrese número:"))
y=int(input("Ingrese número:"))

suma= x+y
resta=x-y
mult=x*y
division=x/y
potencia=x**y
print("Resultados")
print("La suma de ",x," y ",y,"es: ",suma,"\n" ,"La resta de ",x," y ",y,"es: ",resta,"\n","La multiplicacion de ",x," y ",y,"es: ",mult,"\n" ,"La division de ",x," y ",y,"es: ",division,"\n","La potencia de ",x," y ",y,"es: ",potencia,"\n"  )