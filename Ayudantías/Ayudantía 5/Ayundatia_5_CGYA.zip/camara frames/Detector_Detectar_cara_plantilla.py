import sys
from PyQt5 import QtCore, QtGui, QtWidgets, uic
from PyQt5.QtCore import pyqtSlot, Qt
import numpy as np
import cv2
import matplotlib.pyplot as plt

class Ventana(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        
        # Configuraciones 
        self.ui = uic.loadUi('Ventana.ui')  # Asegúrate de que Ventana.ui exista en el mismo directorio
        self.ui.setWindowTitle("Interfaz Gráfica")
        self.ui.resize(760, 420)
        
        self.ui.setWindowIcon(QtGui.QIcon('uoh.jpg'))
        self.ui.setWindowFlags(Qt.WindowCloseButtonHint | Qt.WindowMinimizeButtonHint)
        self.ui.show()
        
        # Señal de video
        self.cap = None
        self.face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_frontalface_default.xml')
        self.detectar_cara = False
        self.detectar_rostro_activado = False

        # Señales del reloj
        self.timer = QtCore.QTimer()  
        self.timer.timeout.connect(self.reloj)
        self.th = 100

        # Señales de los botones
        """
        Conecta los botones de la interfaz
        """

        # Crea una escena para mostrar el histograma en la ventana
        self.scene = QtWidgets.QGraphicsScene()
        self.ui.Histograma.setScene(self.scene)

    def detectar_rostros(self):
        pass
    """
    Implementame
    """
    def cerrar(self):
        pass
    """
    Implementame
    """

    def reloj(self):
        if self.cap is not None:
            ret, frame = self.cap.read()
            if ret and frame.size != 0:
                self.rgb =  cv2.cvtColor(frame, cv2.COLOR_BGR2RGB ) 
                self.gray = cv2.cvtColor(self.rgb, cv2.COLOR_RGB2GRAY)
                self.height, self.width, self.channel = self.rgb.shape
                ret, self.bw = cv2.threshold(self.gray, self.th, 255, cv2.THRESH_BINARY)


    def mostrar(self):
        if self.ui.comboBox.currentText() == 'RGB' and hasattr(self, 'rgb'):
            """
            Implementame
            """
            pass

        elif self.ui.comboBox.currentText() == 'Escala de grises' and hasattr(self, 'gray'): 
            """
            Implementame
            """
            pass
            self.histograma()
        elif hasattr(self, 'bw'):
            """
            Implementame
            """
            pass
            self.scene.clear()

        else:
            return
        """
        Implementame
        """
        pass

    @pyqtSlot()
    def Comenzar(self):
        pass
        """
        Implementame
        """
    @pyqtSlot()
    def Detener(self):
        pass
        """
        Implementame
        """

        
        
    def histograma(self):
        if self.ui.comboBox.currentText() == 'Escala de grises':
            hist = cv2.calcHist([self.gray], [0], None, [256], [0, 256])
            hist_image = self.plot_histogram(hist)
            qim = QtGui.QImage(hist_image.data, hist_image.shape[1], hist_image.shape[0], hist_image.strides[0], QtGui.QImage.Format_RGB888)
            pix = QtGui.QPixmap.fromImage(qim)
            self.scene.clear()  # Limpia la escena antes de agregar una nueva imagen
            self.scene.addPixmap(pix)
        
            

        
    def plot_histogram(self, hist):
        hist = hist.flatten()
        hist_image = np.zeros((256, 256, 3), dtype=np.uint8)
        cv2.normalize(hist, hist, 0, 255, cv2.NORM_MINMAX)
        hist = np.int32(np.around(hist))
        for x, y in enumerate(hist):
            cv2.line(hist_image, (x, 255), (x, 255-y), (255, 0, 0))
        return hist_image

app = QtWidgets.QApplication(sys.argv)
ventana = Ventana()
sys.exit(app.exec_())
