import sys
from PyQt5 import QtGui, QtWidgets, uic, QtCore
from PyQt5.QtCore import pyqtSlot, Qt
from PyQt5 import QtOpenGL
from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *
from Figuras import *  #Importar las figuras, es decir, el archivo donde dibujamos las caras del cubo
import time
import threading
import random
import numpy as np

#Ventana clase OpenGL
class Viewer3DWidget(QtOpenGL.QGLWidget):
    max_xyz = 2.0
    def __init__(self, parent=None):
        QtOpenGL.QGLWidget.__init__(self, parent)
        self.angx = 0  #Valor inicial angulo x
        self.angy = 0  #Valor inicial angulo y
        self.angz = 0  #Valor inicial angulo z
    #Funciones protegidas OpenGL
    def paintGL(self):
        glMatrixMode( GL_MODELVIEW )
        glLoadIdentity()
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glEnable(GL_DEPTH_TEST)
        self.dibujar()
        glFlush()
    ### define las dimensiones y el centro de las caras
    def resizeGL(self, widthInPixels, heightInPixels):
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        glOrtho(-self.max_xyz, self.max_xyz,-self.max_xyz, self.max_xyz,-self.max_xyz, self.max_xyz)
        glViewport(0, 0, widthInPixels, heightInPixels)
    def initializeGL(self):
        glClearColor(0.0, 0.0, 0.0, 1.0)
        glClearDepth(1.0)
    #Metodos-seleccion-figuras
    def dibujar(self):
        
        glRotatef(self.angx, 1.0, 0.0, 0.0)  #Rotamos el angulo x, según el valor entregado en self.angx
        glRotatef(   """completar"""      )  #Rotamos el angulo y, según el valor entregado en self.angy
        glRotatef(   """completar"""      )  #Rotamos el angulo z, según el valor entregado en self.angz
        #Parten con los valores iniciales entregados más arriba
        
        cubo()  #Llamamos la función cubo para dibujar las caras del cubo
        
        glColor3f("""completar""","""completar""","""completar""")  #Elegimos el color para los círculos
        
        '''Número 1'''  #Dibujamos el círculo del número 1, como siempre, el mismo fragmento para dibujar
                        #círculos
        glBegin(GL_POLYGON)
        b=np.arange(0,2*np.pi,(2*np.pi)/30) ## arreglo de puntos
        radio=0.25## Radio del circulo
        for i in b:
            glVertex3f(radio*np.cos(i), radio*np.sin(i), 1.05)  #Acá cambiamos de glVertex2f a glVertex3f
                                                                #ya que, ahora trabajamos en 3D
        glEnd()
        '''Número 1'''


        '''Número 2'''
        ## esquina inferior izquierda
        glBegin(GL_POLYGON)
        b = np.arange(0, 2 * np.pi, (2 * np.pi) / 30)
        radio = 0.25
        
        for i in b:
            glVertex3f("""completar""","""completar""","""completar""")
        glEnd()

        ## esquina inferior derecha
        glBegin(GL_POLYGON)
        b = np.arange(0, 2 * np.pi, (2 * np.pi) / 30)
        radio = 0.25
        
        for i in b:
            glVertex3f("""completar""","""completar""","""completar""")
        glEnd()

        '''Número 2'''

        '''Número 3'''
        glBegin(GL_POLYGON)
        b = np.arange(0, 2 * np.pi, (2 * np.pi) / 30)
        radio = 0.25
        
        for i in b:
            glVertex3f( """completar""","""completar""","""completar""")
        glEnd()

        glBegin(GL_POLYGON)
        b = np.arange(0, 2 * np.pi, (2 * np.pi) / 30)
        radio = 0.25
        
        for i in b:
            glVertex3f(1.05,radio * np.cos(i), radio * np.sin(i))
        glEnd()

        glBegin(GL_POLYGON)
        b = np.arange(0, 2 * np.pi, (2 * np.pi) / 30)
        radio = 0.25
        
        for i in b:
            glVertex3f("""completar""","""completar""","""completar""")
        glEnd()
        '''Número 3'''


        '''Número 4'''
        ##derecha abajo
        glBegin(GL_POLYGON)
        b = np.arange(0, 2 * np.pi, (2 * np.pi) / 30)
        radio = 0.25
        
        for i in b:
            glVertex3f( """completar""","""completar""","""completar""")
        glEnd()
        
        ## izquierda arriba
        glBegin(GL_POLYGON)
        b = np.arange(0, 2 * np.pi, (2 * np.pi) / 30)
        radio = 0.25
        
        for i in b:
            glVertex3f("""completar""","""completar""","""completar""")
        glEnd()
        ### circulo del lado superior derecho
        glBegin(GL_POLYGON)
        b=np.arange(0,2*np.pi,(2*np.pi)/30)
        radio=0.25
        for i in b:
            glVertex3f( """completar""","""completar""","""completar""" )
        glEnd()
        ### circulo del lado derecho inferior
        glBegin(GL_POLYGON)
        b=np.arange(0,2*np.pi,(2*np.pi)/30)
        radio=0.25
        for i in b:
            glVertex3f(-0.5+radio*np.cos(i),-1.05, 0.7+radio*np.sin(i))
        glEnd()
        '''Número 4'''
        
        
        '''Número 5'''
        ##derecha abajo
        glBegin(GL_POLYGON)
        b = np.arange(0, 2 * np.pi, (2 * np.pi) / 30)
        radio = 0.25
        
        for i in b:
            glVertex3f( """completar""","""completar""","""completar""")
        glEnd()
        ##centro
        glBegin(GL_POLYGON)
        b = np.arange(0, 2 * np.pi, (2 * np.pi) / 30)
        radio = 0.25
        
        for i in b:
            glVertex3f("""completar""","""completar""","""completar""")
        glEnd()
        ## izquierda arriba
        glBegin(GL_POLYGON)
        b = np.arange(0, 2 * np.pi, (2 * np.pi) / 30)
        radio = 0.25
        
        for i in b:
            glVertex3f( """completar""","""completar""","""completar""")
        glEnd()
        ### circulo del lado superior derecho
        glBegin(GL_POLYGON)
        b=np.arange(0,2*np.pi,(2*np.pi)/30)
        radio=0.25
        for i in b:
            glVertex3f("""completar""","""completar""","""completar""")
        glEnd()
        ### circulo del lado derecho inferior
        glBegin(GL_POLYGON)
        b=np.arange(0,2*np.pi,(2*np.pi)/30)
        radio=0.25
        for i in b:
            glVertex3f( -1.05, -0.5+radio*np.cos(i), 0.7+radio*np.sin(i))
        glEnd()
        '''Número 5'''
        
        '''Número 6'''  #Ciclos para dibujar los círculos del número 6, como siempre, el mismo fragmento
                        #círculos para dibujar, cambiando de a poco los valores de x e y para acomodarlos
        
        ## circulo del lado derecho medio
        glBegin(GL_POLYGON)
        b=np.arange(0,2*np.pi,(2*np.pi)/30)
        radio=0.25
        for i in b:
            glVertex3f("""completar""","""completar""","""completar""")
        glEnd()
        ### circulo del lado derecho inferior
        glBegin(GL_POLYGON)
        b=np.arange(0,2*np.pi,(2*np.pi)/30)
        radio=0.25
        for i in b:
            glVertex3f("""completar""","""completar""","""completar""")
        glEnd()
        ### circulo 
        glBegin(GL_POLYGON)
        b=np.arange(0,2*np.pi,(2*np.pi)/30)
        radio=0.25
        ##lado superior derecho
        for i in b:
            glVertex3f("""completar""","""completar""","""completar""")
        glEnd()

        ### Circulo 
        glBegin(GL_POLYGON)
        b=np.arange(0,2*np.pi,(2*np.pi)/30)
        radio=0.25
        ##centro izquierdo
        for i in b:
            glVertex3f("""completar""","""completar""","""completar""")
        glEnd()
        

        ### Circulo superior izquierdo
        glBegin(GL_POLYGON)
        b=np.arange(0,2*np.pi,(2*np.pi)/30)
        radio=0.25
        for i in b:
            glVertex3f("""completar""","""completar""","""completar""")
        glEnd()

        ### Circulo inferior izquierdo
        glBegin(GL_POLYGON)
        b=np.arange(0,2*np.pi,(2*np.pi)/30)
        radio=0.25
        for i in b:
            glVertex3f("""completar""","""completar""","""completar""")
        glEnd()
        
        '''Número 6'''
        
#Ventana principal
class Ventana(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = uic.loadUi('Dado.ui')
        self.ui.setWindowIcon(QtGui.QIcon('uoh.jpg'))
        self.ui.setWindowTitle('Dado')
        self.ui.setWindowFlags(Qt.WindowCloseButtonHint | Qt.WindowMinimizeButtonHint)
        self.viewer3D = Viewer3DWidget(self)
        self.ui.OpenGLLayout.addWidget(self.viewer3D)
        self.ui.show()
        # Variables
        self.angx = 0
        self.angy = 0
        self.angz = 0
        self.timerx = QtCore.QTimer()
        self.timery = QtCore.QTimer()
        self.timerz = QtCore.QTimer()
        self.timer_running = False  # Bandera para indicar si el temporizador está en ejecución


        # Signals, conectamos lso botones de la interfaz
        self.ui.pushButton.clicked.connect("""completar""")
        self.ui.actioncerrar.triggered.connect("""completar""")
        self.timerx.timeout.connect("""completar""")
        self.timery.timeout.connect("""completar""")
        self.timerz.timeout.connect("""completar""")
#######################################################################################################
# Funcionamiento de los botones
########################################################################################################
    @QtCore.pyqtSlot()
    def iniciar_temporizadores(self):
        if not self.timer_running:
            self.timer_running = True
            """Aca podemos determinar la velocidad del cambio en los ejes para ver la rotaciones"""
            self.timerx.start("""completar""")  # cada ms
            self.timery.start("""completar""")  # cada ms
            self.timerz.start("""completar""")  # cada ms

            # Iniciar un hilo separado para detener los temporizadores después de 5 segundos, esto podemos variarlo.
            threading.Thread(target=self.detener_temporizadores, args=(5,)).start()

    def detener_temporizadores(self, segundos):
        time.sleep(segundos)
        self.timerx.stop()
        self.timery.stop()
        self.timerz.stop()
        self.timer_running = False

    @QtCore.pyqtSlot()
    def timer_x(self): #Función para rotar el ángulo x con un timer de forma aleatoria
        self.angx += random.randint(1, 360)
        """completar"""
        """completar"""
        """completar"""
        self.viewer3D.updateGL()

    @QtCore.pyqtSlot()
    def timer_y(self): #Función para rotar el ángulo y con un timer de forma aleatoria
        self.angy += random.randint(1, 360)
        """completar"""
        """completar"""
        """completar"""
        self.viewer3D.updateGL()

    @QtCore.pyqtSlot()
    def timer_z(self): #Función para rotar el ángulo z con un timer de forma aleatoria
        self.angz += random.randint(1, 360)
        """completar"""
        """completar"""
        """completar"""
        self.viewer3D.updateGL() 
    
    def cerrar(self):
        self.ui.close()  # Cierra la ventana
        
if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    ventana = Ventana()
    sys.exit(app.exec_())