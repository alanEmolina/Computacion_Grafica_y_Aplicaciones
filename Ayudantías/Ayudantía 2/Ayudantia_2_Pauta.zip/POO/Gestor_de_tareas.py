class Tarea:
    def __init__(self, descripcion, fecha_vencimiento):
        self.descripcion = descripcion
        self.estado = "Pendiente"
        self.fecha_vencimiento = fecha_vencimiento

    def completar(self):
        self.estado = "Completada"
        print(f"Tarea '{self.descripcion}' completada.")

    def eliminar(self):
        self.estado = "Eliminada"
        print(f"Tarea '{self.descripcion}' eliminada.")

    def __str__(self):
        return f"Tarea: {self.descripcion} | Estado: {self.estado} | Fecha de vencimiento: {self.fecha_vencimiento}"


class GestorTareas:
    def __init__(self):
        self.tareas = []

    def crear_tarea(self, descripcion, fecha_vencimiento):
        tarea = Tarea(descripcion, fecha_vencimiento)
        self.tareas.append(tarea)
        print(f"Tarea '{descripcion}' creada con éxito.")

    def listar_tareas(self):
        if not self.tareas:
            print("No hay tareas.")
        else:
            print("Lista de tareas:")
            for tarea in self.tareas:
                print(tarea)

    def completar_tarea(self, descripcion):
        for tarea in self.tareas:
            if tarea.descripcion == descripcion:
                tarea.completar()
                return
        print(f"No se encontró la tarea '{descripcion}'.")

    def eliminar_tarea(self, descripcion):
        for tarea in self.tareas:
            if tarea.descripcion == descripcion:
                tarea.eliminar()
                self.tareas.remove(tarea)
                return
        print(f"No se encontró la tarea '{descripcion}'.")


# Ejemplo de uso
gestor = GestorTareas()
print("Inicializamos las tareas")
gestor.crear_tarea("Hacer la compra", "15-04-2024")
gestor.crear_tarea("Levantarse", "16-04-2024")
gestor.crear_tarea("Hacer deporte", "10-04-2024")
gestor.crear_tarea("Hacer la compra", "10-04-2024")
gestor.crear_tarea("Estudiar para el examen", "9-04-2024")
print("Empezamos a procesar las tareas")
gestor.listar_tareas()
print("Empezamos la tarea")
gestor.completar_tarea("Hacer la compra")
gestor.listar_tareas()
print("Eliminamos la tarea")
gestor.eliminar_tarea("Estudiar para el examen")
gestor.listar_tareas()
