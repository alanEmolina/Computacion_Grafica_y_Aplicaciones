

class Personaje:
    def __init__(self, nombre, salud=100, fuerza=5, destreza=5, inteligencia=5, clase="Aldeano"):
        self.nombre = nombre
        self.salud = salud
        self.fuerza = fuerza
        self.destreza = destreza
        self.inteligencia = inteligencia
        self.clase = clase

    def __str__(self):
        return f"{self.nombre} (Salud: {self.salud}, Fuerza: {self.fuerza}, Destreza: {self.destreza}, Inteligencia: {self.inteligencia}, Clase: {self.clase} )"

    def levantar_pesas(self):
        self.fuerza += 5
        print(f"{self.nombre} ha levantado pesas y aumentado su fuerza en 5 punto.")

    def estudiar(self):
        self.inteligencia += 5
        print(f"{self.nombre} ha estudiado y aumentado su inteligencia en 5 punto.")

    def correr(self):
        self.destreza += 5
        print(f"{self.nombre} ha corrido y aumentado su destreza en 5 punto.")

    def cambiar_clase(self):

        if self.clase == "Aldeano" and self.inteligencia >= 50:
            print(f"{self.nombre} ha ascendido a la clase 'Mago'!")
            self.clase="Mago"
            return self,self.clase
            
        elif self.clase == "Aldeano" and self.fuerza >= 50:
            print(f"{self.nombre} ha ascendido a la clase 'Guerrero'!")
            self.clase="Guerrero"
            return self,self.clase
        elif self.clase == "Aldeano" and self.destreza >= 50:
            print(f"{self.nombre} ha ascendido a la clase 'Arquero'!")
            self.clase="Arquero"
            return self,self.clase
        else:
            print(f"{self.nombre} no cumple los requisitos para cambiar de clase.")
            return self,self.clase

        

"""
def crear_personaje():
    nombre = input("Introduce el nombre del personaje: ")
    salud = 100
    fuerza = input("Introduce la cantidad de fuerza:")
    destreza = input("Introduce la cantidad de destreza:")
    inteligencia = input("Introduce la cantiada de inteligencia:")
    return Personaje(nombre, salud, fuerza, destreza, inteligencia)
"""

def crear_personaje():
    nombre = input("Introduce el nombre del personaje: ")
    return Personaje(nombre)

