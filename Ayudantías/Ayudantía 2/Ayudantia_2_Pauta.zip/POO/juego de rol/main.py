from Personaje import crear_personaje



print("############################################################################################################")
print("Bienvenido a mundo virtual")
print("En este nuevo mundo existen muchas personas. Empecemos por crear tu personaje para introducirte al mundo nuevo\n")

# Crear un nuevo personaje
nuevo_personaje = crear_personaje()
actualizacion_personaje=[]

print("Nuevo personaje creado:")
print("¡Felicidades! Has creado tu personaje\n")
print("Se mostrara tu personaje en este momento\n")
print(nuevo_personaje)

print("Deseas fortalecer tu personaje, te esperan grandes sorpresas")
print("Tenemos varias acciones a realizar, escoge una")
print("Actividades:")
print(" 1) Levantar pesas")
print(" 2) Estudiar")
print(" 3) Correr")
print(" Salir con 0")

opc = int(input("Ingrese su elección: "))

while opc != 0:
    if nuevo_personaje.fuerza >= 50:
        print("WOW, tu personaje ya posee la fuerza necesaria para escoger una clase superior llamada 'Guerrero'")
        print("¿Deseas cambiar la clase?")
        b = input("Escriba su preferencia (Y/N): ")
        if b == "Y":
            print("Inicia el cambio de clase")
            actualizacion_personaje = nuevo_personaje.cambiar_clase()
            print("Clase cambiada exitosamente:")
            print(actualizacion_personaje)

    if nuevo_personaje.destreza >= 50:
        print("WOW, tu personaje ya posee la destreza necesaria para escoger una clase superior llamada 'Arquero'")
        print("¿Deseas cambiar la clase?")
        b = input("Escriba su preferencia (Y/N): ")
        if b == "Y":
            print("Inicia el cambio de clase")
            actualizacion_personaje = nuevo_personaje.cambiar_clase()
            print("Clase cambiada exitosamente:")
            print(actualizacion_personaje)

    if nuevo_personaje.inteligencia >= 50:
        print("WOW, tu personaje ya posee la inteligencia necesaria para escoger una clase superior llamada 'Mago'")
        print("¿Deseas cambiar la clase?")
        b = input("Escriba su preferencia (Y/N): ")
        if b == "Y":
            print("Inicia el cambio de clase")
            actualizacion_personaje = nuevo_personaje.cambiar_clase()
            print("Clase cambiada exitosamente:")
            print(actualizacion_personaje)

    if opc == 1:
        print(nuevo_personaje.nombre, ", Levantando pesas....")
        print(nuevo_personaje.nombre, ", Levantando pesas....")
        print(nuevo_personaje.nombre, ", Levantando pesas....")
        print(nuevo_personaje.nombre, ", Levantando pesas....")
        print(nuevo_personaje.nombre, ", Levantando pesas....")
        print(nuevo_personaje.nombre, ", Levantando pesas....")
        nuevo_personaje.levantar_pesas()
        print("Felicidades, tus estadísticas cambiaron, verifícalas:", nuevo_personaje)
    elif opc == 2:
        print(nuevo_personaje.nombre, ", Estudiando....")
        print(nuevo_personaje.nombre, ", Estudiando....")
        print(nuevo_personaje.nombre, ", Estudiando....")
        print(nuevo_personaje.nombre, ", Estudiando....")
        print(nuevo_personaje.nombre, ", Estudiando....")
        print(nuevo_personaje.nombre, ", Estudiando....")
        nuevo_personaje.estudiar()
        print("Felicidades, tus estadísticas cambiaron, verifícalas:", nuevo_personaje)
    elif opc == 3:
        print(nuevo_personaje.nombre, ", Corriendo....")
        print(nuevo_personaje.nombre, ", Corriendo....")
        print(nuevo_personaje.nombre, ", Corriendo....")
        print(nuevo_personaje.nombre, ", Corriendo....")
        print(nuevo_personaje.nombre, ", Corriendo....")
        print(nuevo_personaje.nombre, ", Corriendo....")
        nuevo_personaje.correr()
        print("Felicidades, tus estadísticas cambiaron, verifícalas:", nuevo_personaje)
    else:
        print("Opción no válida. Por favor, seleccione una opción válida.")

    print("")
    print("Deseas fortalecer tu personaje más? Elige una actividad:")
    print(" 1) Levantar pesas")
    print(" 2) Estudiar")
    print(" 3) Correr")
    print(" Salir con 0")
    opc = int(input("Ingrese su elección: "))

print("¡Genial, acabaste tu entrenamiento!")
print("Tu personaje quedó con estas estadísticas, verifícalas:")
print(nuevo_personaje)

