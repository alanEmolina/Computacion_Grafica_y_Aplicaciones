class Rectangulo:
    def __init__(self, base, altura):
        self.base = base
        self.altura = altura
    
    def area(self):
        return self.base * self.altura
    
    def perimetro(self):
        return 2 * (self.base + self.altura)
    
    def es_cuadrado(self):
        return self.base == self.altura

# Ejemplo de uso
base = float(input("Ingrese la base del rectángulo: "))
altura = float(input("Ingrese la altura del rectángulo: "))

mi_rectangulo = Rectangulo(base, altura)

print("Área del rectángulo:", mi_rectangulo.area())
print("Perímetro del rectángulo:", mi_rectangulo.perimetro())

if mi_rectangulo.es_cuadrado():
    print("El rectángulo es un cuadrado.")
else:
    print("El rectángulo no es un cuadrado.")
