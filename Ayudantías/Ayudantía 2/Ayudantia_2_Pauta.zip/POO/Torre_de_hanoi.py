def torre_hanoi(n, origen, destino, auxiliar):
    if n == 1:
        print(f"Mueve el disco 1 de {origen} a {destino}")
        return
    torre_hanoi(n-1, origen, auxiliar, destino)
    print(f"Mueve el disco {n} de {origen} a {destino}")
    torre_hanoi(n-1, auxiliar, destino, origen)

def resolver_hanoi(numero_discos, origen='A', destino='C', auxiliar='B'):
    print(f"Resolviendo el rompecabezas de la Torre de Hanoi para {numero_discos} discos:")
    torre_hanoi(numero_discos, origen, destino, auxiliar)
    print("¡Rompecabezas resuelto!")

# Ejemplo de uso
numero_discos = 3
resolver_hanoi(numero_discos)
