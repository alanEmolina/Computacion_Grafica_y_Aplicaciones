#EJERCICIOS DE CICLOS
"""
e) Escriba un programa que calcule la sumatoria desde uno a un número 
ingresado por el usuario. Considerar ciclo for y luego ciclo while.


#Con ciclo while
n = int(input("Ingrese un número: "))
suma_total = 0 #Creamos una variable que irá guardando la suma
cont = 1 #Creamos un contador que indica las veces que se repite el ciclo
while(cont<n+1): #Lo que indica esta condición es que se repetirá el ciclo hasta que llegue a n
    suma_total = suma_total + cont #Realizamos la suma
    cont = cont + 1 
    print(suma_total)
    
#Con ciclo for    
n2 = int(input("Ingrese un número: "))
suma_total2 = 0
for cont2 in range(1,n2+1): #El range, quiere decir rango, es decir nos permite saber
                            #desde y hasta donde se repetirá el ciclo, suele tener 
                            #como argumento initial_value, stop_value y step_value
                            #En este caso le decimos que empiece en 1 hasta n2
    suma_total2 = suma_total2 + cont2
    print(suma_total2)
    


"""














"""
f) Escriba un programa que permita crear una lista de n números mayores que cero. Tanto n como los
números deben ser solicitados al usuario. El programa solo debe permitir el ingreso de números mayores
a cero. En caso contrario, se debe esperar el ingreso de un número correcto. muestra lista impar
"""
n = int(input('Por favor ingrese valores mayores a 0: '))               #Debe ingresar la cantiadad de números a ingresar
lista = []                                                              #Creamos una lista vacía la cual será llenada con los valores que se ingresaran los valores iniciales


#Inicio del while.
while True:                                                             # Creamos un ciclo para insistir que ingrese un número positivo. 
    if n<0:                                                             # Creamos un condicional ya que no pueden haber números negativos.
            n = int(input('Por favor ingrese valores mayores a 0: '))
    else:
        break                                                           # Funcion que detiene las iteraciones, para un while true siempre debe contener uno, sino nunca para.
""" 
!!!!!   Modificacion que se hizo fue sacar el for que estaba dentro del while; 
Esto logrando que se puedan ingresar datos al primer arreglo y continuar con el codigo  !!!
"""

for i in range(n):                                                      #Creamos un ciclo que recorre hasta lo que el usuario indica con el numero ingresado al inicio del codigo
            Número_para_ingresar= int(input('Diga los valores: '))      # Esta es una variable local que ingresa los valores, perfectamente puede ser otra letra y 
            lista.append(Número_para_ingresar)                          # Agregamos los valores a la lista e imprimimos        
lista_de_impares=[]                                                     # Creamos una lista de impares que seran guardados

                                                                        # Vamos a filtrar los valores dejando solo los impares
for a in lista: 
    if (a%2==0):                                                        # Condicion que evalua si son pares.
        continue                                                        # Esta funcion salta todo el codigo que sigue y pasa a la siguiente iteracion, en este caso se mueve una posicion en el arreglo.
    else:
        lista_de_impares.append(a)                                      # Agregamos a la lista de impares
    
print("lista de numeros sin filtrar:",lista)                            # Muestra lista completa
print("lista de numeros filtrada:",lista_de_impares)                    # Muestra lista filtrada, solo con impares.
print("lista de numeros ordenada y filtrada",sorted(lista_de_impares))  # Muestra lista filtrada y ordenada


