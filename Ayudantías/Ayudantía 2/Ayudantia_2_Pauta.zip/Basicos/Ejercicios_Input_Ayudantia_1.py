#EJERCICIOS DE INPUT
"""


Escriba programas que a partir de dos variables de entrada permitan calcular:
a) voltaje [V] según Ley de Ohm: V = R[Ω] × I[A]"""

R = float(input("Ingrese la resistencia: "))            # Pedimos la resistencia
I = float(input("Ingrese la corriente: "))              # Pedimos la corriente
V = R*I                                                 # Aplicamos la fórmula para calcular el voltaje
print("El voltaje obtenido es: ", V)


"""
b) Índice de Masa Corporal, IMC = masa[Kg]/altura**2[m2]

"""

a = float(input("Ingrese la altura (en metros): "))                 # Pedimos la altura
p = float(input("Ingrese el peso (en kilos): "))                   # Pedimos el peso
imc = p/(a**2)                                          # Aplicamos la fórmula para calcular el imc
print("El imc es: ", imc)