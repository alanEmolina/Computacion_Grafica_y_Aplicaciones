#EJERCICIOS DE CONDICIONALES 
"""
c) Escriba un programa que dado tres números determine cual es el menor

"""
n1 = float(input("Ingrese un número: "))
n2 = float(input("Ingrese un segundo número: "))
n3 = float(input("Ingrese un tercer número: "))

if (n1<n2) and (n1<n3):                         # Primero comparamos n1 con n2 y n3
    print("El número menor es: ", n1)
elif (n2<n1) and (n2<n3):                       # Luego comparamos n2 con n1 y n3
    print("El número menor es: ", n2) 
else:                                           # Y solo nos queda el caso de que sea n3 el menor de los números, entonces...
    print("El número menor es: ", n3)
    


"""
d) Escriba un programa que muestre si un número es par o impar
"""

num = float(input("Ingrese un número: "))       # Ingresa el numero
if (num%2==0):                                  # El símbolo % le llamamos módulo y calcula el resto de las divisiones
    print("El número es par")
else:
    print("El número es impar")

    