def perfecto(n):
    cont=2
    perfecto=0
    if n<2:
        return False
    else:
        while perfecto <n:
            perfecto=2**(cont-1)+(2**cont)-1
            if perfecto==n:
                return True
            else:
                cont =+ 1
    return False
perfecto(6)                