def invertir_cadena(cadena):
    # Verifica si la cadena está vacía
    if len(cadena) == 0:
        # Si la cadena está vacía, no hay nada que invertir, así que se devuelve la cadena tal cual
        return cadena
    else:
        # Si la cadena no está vacía, se llama recursivamente a invertir_cadena
        # con una porción de la cadena que excluye el primer carácter (cadena[1:])
        # y se concatena con el primer carácter de la cadena original (cadena[0])
        return invertir_cadena(cadena[1:]) + cadena[0]





print("Inicio del programa que invierte una cadena")
a = input("Ingrese su cadena de texto:")
print(a)
print("Su cadena invertida es:",invertir_cadena(a))  
