##    Queremos realizar un el factorial de un numero

## Recursion

def factorial_recursion(n):
    if n == 0:
        return 1
    else:
        return n * factorial_recursion(n-1) 




## Sin recursion

def factorial_sin_recursion(n):
    resultado = 1
    for i in range(1, n + 1):
        resultado *= i
    return resultado


print(factorial_sin_recursion(20))  
print(factorial_recursion(20))  