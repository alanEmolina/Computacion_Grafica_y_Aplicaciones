## Dar una serie de fibonacci dado un numero

def fibonacci_recursion(n):
    # Comprobamos si n es menor o igual a 1
    if n <= 1:
        # Si n es 0 o 1, retornamos n
        # Ya que los primeros dos términos de la secuencia son 0 y 1
        return n
    else:
        # Si n es mayor que 1, calculamos el término n de la secuencia de Fibonacci
        # llamando recursivamente a la función para los términos n-1 y n-2
        # y sumando los resultados
        return fibonacci_recursion(n-1) + fibonacci_recursion(n-2)



## Sin recursion #####
def fibonacci_sin_recursion(n):
    # Comprobamos si n es menor o igual a 1
    if n <= 1:
        # Si es así, retornamos n
        # Ya que los primeros dos términos de la secuencia son 0 y 1
        return n
    else:
        # Si n es mayor que 1, inicializamos los primeros dos términos de la secuencia
        a, b = 0, 1
        
        # Iteramos desde 2 hasta n-1
        for _ in range(n - 1):
            # En cada iteración, actualizamos los términos de la secuencia
            # a es el término n-1, b es el término n
            # El siguiente término de la secuencia será la suma de a y b
            a, b = b, a + b
        
        # Al salir del bucle, b contendrá el término n de la secuencia
        return b


# Ejemplos:
print("Vamos a evaluar ambos casos")
print("Funcion recursiva")
print(fibonacci_sin_recursion(7))  # Salida: 13
print()
print("###############################################################################")
print("Funcion sin recursiva")
print(fibonacci_recursion(7))  # Salida: 13