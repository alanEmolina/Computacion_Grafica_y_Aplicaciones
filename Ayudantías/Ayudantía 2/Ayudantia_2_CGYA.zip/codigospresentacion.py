import matplotlib.pyplot as plt

plt.pie([30, 40, 30], labels=['A', 'B', 'C'], autopct='%1.1f%%')
plt.show()

plt.stackplot([1,2,3,4], [3,4,5,6])
plt.show()

plt.bar(['A', 'B', 'C'], [10, 20, 15])
plt.show()

plt.scatter([1,2,3], [4,5,6])
plt.show()

datos = [1,2,2,3,3,3,4,4,4,4]
plt.hist(datos, bins=4)
plt.show()
