#EJERCICIO DE FUNCIONES
"""
g) A partir del ejemplo f), escriba una función que reciba como argumento el
valor de n y retorne la suma de todos los números impares de la lista.

"""
def suma_impares(n): 
    suma_total_imp = 0 #Creamos una variable que guardará la suma
    lista = [] #Creamos una lista donde guardaremos los números
    if n<0: #Nos guiamos por el ejercicio anterior
        while True:
            n = int(input('Por favor ingrese valores mayores a 0 '))
            if n>=0:
                break
    elif n>=0:
        for values in range(n):
            n = int(input('Diga los valores: '))
            lista.append(n)
        for i in lista: #Creamos un ciclo para realizar la suma
            if i%2!=0: #Creamos una condición para que se realice la suma
                       #solo para impares
                suma_total_imp = i + suma_total_imp
    return lista, suma_total_imp

print(suma_impares(3)) #Llamamos e imprimimos la función 
    