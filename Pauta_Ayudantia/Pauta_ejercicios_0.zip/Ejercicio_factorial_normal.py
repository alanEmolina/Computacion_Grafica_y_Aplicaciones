def factorial_normal(n):
    r = 1           #inicializa variable
    i = 2           #inicializa variable
    while i <= n:
        r *= i
        i += 1
    return r

print("factorial de 5:",factorial_normal(5)) # 120