#EJERCICIOS DE CICLOS
"""
e) Escriba un programa que calcule la sumatoria desde uno a un número 
ingresado por el usuario. Considerar ciclo for y luego ciclo while.

"""
#Con ciclo while
n = int(input("Ingrese un número: "))
suma_total = 0 #Creamos una variable que irá guardando la suma
cont = 1 #Creamos un contador que indica las veces que se repite el ciclo
while(cont<n+1): #Lo que indica esta condición es que se repetirá el ciclo hasta que llegue a n
    suma_total = suma_total + cont #Realizamos la suma
    cont = cont + 1 
    print(suma_total)
    
#Con ciclo for    
n2 = int(input("Ingrese un número: "))
suma_total2 = 0
for cont2 in range(1,n2+1): #El range, quiere decir rango, es decir nos permite saber
                            #desde y hasta donde se repetirá el ciclo, suele tener 
                            #como argumento initial_value, stop_value y step_value
                            #En este caso le decimos que empiece en 1 hasta n2
    suma_total2 = suma_total2 + cont2
    print(suma_total2)
    


"""
f) Escriba un programa que permita crear una lista de n números mayores que cero. Tanto n como los
números deben ser solicitados al usuario. El programa solo debe permitir el ingreso de números mayores
a cero. En caso contrario, se debe esperar el ingreso de un número correcto.

"""
lista = [] #Creamos una lista vacía la cual será llenada con los valores que
           #entregue el usuario
n = int(input('¿Cuántos valores desea ingresar?: '))
if n<0: #Creamos un condicional ya que no pueden haber números negativos
    while True: #Creamos un ciclo para insistir que ingrese un número positivo
        n = int(input('Por favor ingrese valores mayores a 0: '))
        if n>=0: #Cuando ya ingrese un número positivo rompemos el ciclo
            break
elif n>=0:
    for i in range(n): #Creamos un ciclo que recorre hasta lo que el usuario indica
                       #en el primer input
        n = int(input('Diga los valores: ')) 
        lista.append(n) #Agregamos los valores a la lista e imprimimos
print(lista)