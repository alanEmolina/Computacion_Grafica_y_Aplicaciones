from Personaje import Personaje



class Mago(Personaje):
    def __init__(self, personaje):
        super().__init__(personaje.nombre, personaje.salud, personaje.fuerza, personaje.destreza, personaje.inteligencia)
        self.clase = "Mago"
