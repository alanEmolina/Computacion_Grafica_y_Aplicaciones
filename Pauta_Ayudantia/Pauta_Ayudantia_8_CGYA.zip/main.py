import sys
import random
from PyQt5 import QtGui, QtWidgets, uic
from PyQt5.QtCore import pyqtSlot, Qt
from PyQt5 import QtOpenGL
from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *
from figuras import *

# Ventana Clase OpenGL
class Viewer3DWidget(QtOpenGL.QGLWidget):
    max_xyz = 2.0

    def __init__(self, parent=None):
        super(Viewer3DWidget, self).__init__(parent)
        self.angx = 0
        self.angy = 0
        self.angz = 0
        self.escala = 1.0  # Añadir atributo de escala

    # Funciones protegidas OpenGL
    def paintGL(self):
        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glEnable(GL_DEPTH_TEST)
        self.dibujar()
        glFlush()

    def resizeGL(self, widthInPixels, heightInPixels):
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        aspect_ratio = widthInPixels / heightInPixels
        if widthInPixels <= heightInPixels:
            glOrtho(-self.max_xyz * aspect_ratio, self.max_xyz * aspect_ratio, -self.max_xyz, self.max_xyz, -self.max_xyz, self.max_xyz)
        else:
            glOrtho(-self.max_xyz, self.max_xyz, -self.max_xyz / aspect_ratio, self.max_xyz / aspect_ratio, -self.max_xyz, self.max_xyz)
        glViewport(0, 0, widthInPixels, heightInPixels)

    def initializeGL(self):
        glClearColor(0.0, 0.0, 0.0, 1.0)
        glClearDepth(1.0)

    # Métodos-Seleccion-Figuras
    def dibujar(self):
        glRotatef(self.angx, 1.0, 0.0, 0.0)
        glRotatef(self.angy, 0.0, 1.0, 0.0)
        glRotatef(self.angz, 0.0, 0.0, 1.0)
        cubo(self.escala)  # Pasar la escala actual

# Ventana principal
class Ventana(QtWidgets.QMainWindow):
    def __init__(self):
        super(Ventana, self).__init__()
        self.ui = uic.loadUi('Main.ui', self)
        self.ui.setWindowIcon(QtGui.QIcon('uoh.jpg'))
        self.ui.setWindowFlags(Qt.WindowCloseButtonHint | Qt.WindowMinimizeButtonHint)

        # Verificar que el widget 'widget' existe en el archivo UI
        if hasattr(self.ui, 'widget'):
            layout = QtWidgets.QVBoxLayout(self.ui.widget)  # Usar un layout
            self.viewer3D = Viewer3DWidget(self)
            layout.addWidget(self.viewer3D)  # Añadir viewer3D al layout
        else:
            raise AttributeError("El archivo Main.ui no contiene un widget llamado 'widget'")

        self.ui.show()

        # Verificar la existencia de los sliders
        if not (hasattr(self.ui, 'ejex') and hasattr(self.ui, 'ejey') and hasattr(self.ui, 'ejez')):
            raise AttributeError("El archivo Main.ui debe contener los sliders 'ejex', 'ejey', y 'ejez'")
        
        # Asegurarse de que los sliders son del tipo correcto
        print(f"rotarx: {type(self.ui.ejex)}, rotary: {type(self.ui.ejey)}, rotarz: {type(self.ui.ejez)}")
        if not (isinstance(self.ui.ejex, QtWidgets.QSlider) and 
                isinstance(self.ui.ejey, QtWidgets.QSlider) and 
                isinstance(self.ui.ejez, QtWidgets.QSlider)):
            raise TypeError("Los widgets 'rotarx', 'rotary', y 'rotarz' deben ser del tipo QSlider")

        # Conectar los sliders a las funciones de rotación
        self.ui.ejex.valueChanged.connect(self.rotarx)
        self.ui.ejey.valueChanged.connect(self.rotary)
        self.ui.ejez.valueChanged.connect(self.rotarz)

        # Conectar el botón "escala" a la función de escalado aleatorio
        if hasattr(self.ui, 'escala'):
            self.ui.escala.clicked.connect(self.escalar)
        else:
            raise AttributeError("El archivo Main.ui debe contener un botón llamado 'escala'")

        # Verificar la existencia del QLabel para mostrar la escala
        if not hasattr(self.ui, 'label_escala'):
            raise AttributeError("El archivo Main.ui debe contener un QLabel llamado 'label_escala'")

    # Slots
    @pyqtSlot()
    def rotarx(self):
        ang = int(self.ui.ejex.value())
        self.viewer3D.angx = ang
        self.ui.labelx.setText(str(ang))
        self.viewer3D.updateGL()

    @pyqtSlot()
    def rotary(self):
        ang = int(self.ui.ejey.value())
        self.viewer3D.angy = ang
        self.ui.labely.setText(str(ang))
        self.viewer3D.updateGL()

    @pyqtSlot()
    def rotarz(self):
        ang = int(self.ui.ejez.value())
        self.viewer3D.angz = ang
        self.ui.labelz.setText(str(ang))
        self.viewer3D.updateGL()

    @pyqtSlot()
    def escalar(self):
        escala = random.uniform(0.5, 2.0)  # Generar un valor de escala aleatorio entre 0.5 y 2.0
        self.viewer3D.escala = escala
        # Formatear la cadena con dos decimales
        self.ui.label_escala.setText(f"Escala: {escala:.2f}")
        self.viewer3D.updateGL()


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    ventana = Ventana()
    sys.exit(app.exec_())