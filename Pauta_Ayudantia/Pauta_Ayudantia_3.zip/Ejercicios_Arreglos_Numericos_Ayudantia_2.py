# EJERCICIOS ARREGLOS NUMÉRICOS 

"""
El producto escalar de los vectores ⃗u = (u1, u2 · · · un) y ⃗v = (v1, v2, · · · vn).
se puede calcular según: ⃗u · ⃗v = u1 · v1 + u2 · v2, · · · un · vn. 
Construya un programa Python que lea dos vectores de n elementos y
que calcule el producto escalar entre estos.

"""

import numpy as np #Importamos la librer�a para luego crear arreglos 

def validar(msje, inf, sup): #Creamos funci�n que obliga al usuario a crear
                             #vectores mayores que 2 
    numero = int(input('Ingrese valor '+msje)) 
    if inf!=sup: #Deben tener el mismo tama�o
        while numero<inf or numero>sup: #Si no cumple con el requisito le insistimos
            numero = int(input('Error\nIngrese valor '+msje))
    else:
        while numero<inf:
            numero = int(input('Error\nIngrese valor '+msje))
    return numero

def producto_escalar(u,v): #Creamos funci�n para calcular el producto escalar
    s = 0
    N = len(u) #Ya que tienen el mismo largo ambos vectores basta con el largo de uno
    for i in range(N): #Recorremos el vector
        s = s+u[i]*v[i] #Y vamos multiplicando elemento por elemento
    return s #Retornamos el resultado

n = validar('n>2: ', 3,3) #Llamamos la funci�n
i = 0 #Contador
A = np.empty(n) #Arreglo de zeros
B = np.empty(n) #Alternativa a zeros
while i<n:
    a = float(input('A: ')) #Pedimos los valores del vector A
    b = float(input('B: ')) #Pedimos los valores del vector B
    A[i] = a #Por cada �ndice del arreglo va dandole el valor pedido  
    B[i] = b
    i = i+1
print(A,B)
print(producto_escalar(A,B))




"""
Una matriz A es simétrica cuando sus elementos aij son iguales a los aji. 
Escriba un programa Python que lea una matriz AN×N , con 2 ≤ N < 100, 
y que determine si es o no simétrica.

"""

import numpy as np #Importamos la librer�a para luego crear arreglos 

def validar(msje, inf, sup): #Creamos funci�n que obliga al usuario a crear
                             #matrices desde 2 al 99 
    numero = int(input('Ingrese valor '+msje)) #Si no cumple con el requisito le insistimos
    if inf!=sup:
        while numero<inf or numero>sup:
            numero = int(input('Error\nIngrese valor '+msje))
    else:
        while numero<inf:
            numero = int(input('Error\nIngrese valor '+msje))
    return numero

def matriz_simetrica(m): #Funci�n para definir si la matriz es sim�trica
    x,y = m.shape 
    s = 0  #Creamos un contador de coordenadas iguales
    for i in range(x): #Con los ciclos recorremos las coordenadas de la matriz
        for j in range(y):
            if m[i][j] == m[j][i]:
                s = s+1 #Si son iguales le sumamos 1 al contador
    if s==(x*y):
        print('La matriz es simétrica')
    else:
        print('La matriz no es simétrica')


N = validar('100>N>=2: ', 2, 99) #Llamamos la funci�n
A = np.empty((N,N)) #Crea una matriz de 0
i = 0 #Contador para i's
while i<N:
    j = 0 #Contador para j's
    while j<N:
        valor = float( input(f'Ingrese valor {i,j}: ') )  #Pedimos los valores de cada coordenada
        A[i,j] = valor #Equivalente a A[i][j] en notación de listas
        j = j+1
    i = i+1

print(A)

matriz_simetrica(A)