import numpy as np

def crear_matriz(filas, columnas):
    A = []
    
    for i in range(filas):
        A.append([])
        for j in range(columnas):
            valor=int(input(f"Digite el valor {i+1} {j+1} de la matriz:"))   
            A[i].append(valor)       
    return A

def imprimir_matriz(A):
    for fila in A:
        print(fila)

filas = int(input("Ingresar numero de filas:  "))
columnas = int(input("Ingresar numero de columnas:  "))
A = crear_matriz(filas, columnas)
print("Matriz creada:")
imprimir_matriz(A)
A=np.array(A)





print("Creacion de una matriz")
print()

fila=int(input("Digito el numero de fila: "))                            # Pedimos el numero de filas que tendra la matriz para su dimension 
columna=int(input("Digite el numero de columnas: "))                     # Pedimos el número de columnas que tendra la matriz para su dimesion

B=[]                                                                # Variable donde alojaremos la matriz
print()
for i in range(fila):                                                    # Iniciamos un for que recorrera las filas de la matriz entre 0 y el numero de variable fila que solicitamos en un inicio
    B.append([])                                                    # Agrega una fila vacia para empezar a llenar por poscicion M i,j
    for j in range(columna):                                             # For que recorrera por columnas en la fila i fijada en el for de arriba
        valor=int(input(f"Digite el valor {i+1} {j+1} de la B:"))   # Ingreso de valor en la posicion M i,j
        B[i].append(valor)                                          # Agregar en la posicion i con la posicion j el valor ingresado


for i in B:                                                         # Eecorre la variable matriz
    print(i, end= ' ')                                                   # Muestra la matriz por fila y salta linea
    print()                                                              # Salto de linea
B=np.array(B)


print("##############################################################")

print("Quiere usar una operecion matricial?")
print("Escoja la opcion:")
print("1) Suma")
print("2) Resta")
print("3) Multiplicacion por escalar")
print("4) Multiplicacion de Matrices")
print("5) Inversion de matrices")
print("6) Transposicion")
num=int(input("Ingrese una opcion valida: "))
# Suma de matrices

if num == 1:
    suma_matrices = A + B
    print("Suma de matrices:")
    print(suma_matrices)

if num == 2:   
    # Resta de matrices
    resta_matrices = A - B
    print("\nResta de matrices:")
    print(resta_matrices)

if num == 3:  
    # Multiplicación por un escalar
    escalar = int(input("Ingrese valor de escalar: "))
    multiplicacion_escalar = escalar * A
    print("\nMultiplicación por un escalar:")
    print(multiplicacion_escalar)

if num == 4:  
    # Multiplicación de matrices
    multiplicacion_matrices = np.dot(A, B)
    print("\nMultiplicación de matrices:")
    print(multiplicacion_matrices)

if num == 5:  
    # Inversión de matrices
    try:
        inversa_A = np.linalg.inv(A)
        print("\nInversión de matriz A:")
        print(inversa_A)
    except np.linalg.LinAlgError:
        print("\nLa matriz A no es invertible.")
    
    try:
        inversa_B = np.linalg.inv(B)
        print("\nInversión de matriz B:")
        print(inversa_B)
    except np.linalg.LinAlgError:
        print("\nLa matriz B no es invertible.")

if num == 6:  
    # Transposición de matrices
    transpuesta_A = np.transpose(A)
    print("\nTransposición de matriz A:")
    print(transpuesta_A)