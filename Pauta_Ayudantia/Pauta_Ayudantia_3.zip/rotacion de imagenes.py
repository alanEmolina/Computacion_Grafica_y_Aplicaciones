import cv2
import numpy as np

# Cargar la imagen
image = cv2.imread("image.png")

# Redimensionar la imagen a 800x600
image = cv2.resize(image, (800, 600))

# Obtener el tamaño de la imagen
height, width = image.shape[:2]

# Calcular el ángulo de rotación (en radianes)
angle = 90
theta = np.radians(angle)
"""
# Calcular el centro de la imagen
center_x = width / 2
center_y = height / 2
"""
# Calcular el centro de la imagen
center_x = width /1.5
center_y = height / 1.5

# Definir la matriz de transformación de rotación
rotation_matrix = np.array([
    [np.cos(theta), -np.sin(theta), (1 - np.cos(theta)) * center_x + np.sin(theta) * center_y],
    [np.sin(theta), np.cos(theta), (1 - np.cos(theta)) * center_y - np.sin(theta) * center_x]
])

# Aplicar la rotación a la imagen
rotated_image = cv2.warpAffine(image, rotation_matrix, (width, height), flags=cv2.INTER_LINEAR)

# Redimensionar la imagen rotada a 800x600
rotated_resized_image = cv2.resize(rotated_image, (800, 600))

# Mostrar la imagen original y la imagen rotada y redimensionada
cv2.imshow("Original", image)
cv2.imshow("Rotada y Redimensionada", rotated_resized_image)
cv2.waitKey(0)
cv2.destroyAllWindows()
