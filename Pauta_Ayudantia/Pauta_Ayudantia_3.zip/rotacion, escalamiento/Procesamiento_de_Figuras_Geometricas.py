# EJERCICIO OPENGL

"""
Diseñar e implementar una interfaz gráfica para el procesamiento de figuras geométricas básicas (cuadrado,
rectángulo, triangulo, círculo)

Dibujar con OpenGL figuras geométricas básicas (cuadrado, rectángulo, triangulo, círculo)

Incluir widgets para la selección de la figura a dibujar

Incluir widgets para el cambio de colores y dimensiones de las figuras

Incluir widgets para transformaciones de traslación, escalado y rotación

"""

import sys
from PyQt5 import QtGui, QtWidgets, uic
from PyQt5.QtCore import pyqtSlot, Qt
from PyQt5 import QtOpenGL
from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *
import numpy as np

#Ventana clase OpenGL
#Ventana principal
class Ventana(QtWidgets.QMainWindow):
   def __init__(self):
      super().__init__()
      self.ui = uic.loadUi('Procesamiento.ui') #Cargamos interfaz
      self.ui.setWindowIcon(QtGui.QIcon('uoh.jpg')) #Elegimos ícono
      self.ui.setWindowFlags(Qt.WindowCloseButtonHint | Qt.WindowMinimizeButtonHint) #Inhabilitamos el botón minimizar
      self.viewer3D = Viewer3DWidget(self) #Guardamos la clase Viewer3DWidget
      self.ui.OpenGLLayout.addWidget(self.viewer3D) #Creamos una ventana del tipo OpenGLLayout
      self.ui.show() #Mostramos archivo .ui en pantalla
      #variables
      self.colores = ['r', 'g', 'b', 'p'] #Variable para guardar los colores
      self.figuras = ['triangulo', 'cuadrado','circulo','rectangulo'] #Variable para guardar las figuras
      #signals
      self.ui.figura.currentIndexChanged.connect(self.cambioFigura) #Cambiamos la figura según lo que diga el combo box
      self.ui.color.currentIndexChanged.connect(self.cambioColor) #Cambiamos el color según lo que diga el combo box

   #slots
   @pyqtSlot()
   def cambioFigura (self):
       index_figura = self.ui.figura.currentIndex() #Guardamos en una variable el texto del combo box de figuras
       self.viewer3D.figura = self.figuras[index_figura] #Le asignamos la variable self.figura de la clase 
                                                        #Viewer3DWidget donde guardamos el texto del combo box
       self.viewer3D.updateGL() #Actualizamos la ventana
   @pyqtSlot()
   def cambioColor (self):
       index_color = self.ui.color.currentIndex() #Guardamos en una variable el texto del combo box de colores
       self.viewer3D.color = self.colores[index_color] #Le asignamos la variable self.color de la clase 
                                                       #Viewer3DWidget donde guardamos el texto del combo box
       self.viewer3D.updateGL() #Actualizamos la ventana
      
class Viewer3DWidget(QtOpenGL.QGLWidget): #Creamos la clase donde dibujamos
    def __init__(self, parent=None):
        QtOpenGL.QGLWidget.__init__(self, parent)
        self.figura = 'triangulo' #Empezamos abriendo la ventana dibujando un triangulo 
        self.colores = {'r':[255,0,0], 'g':[0,255,0], 'b':[0,0,255], 'p':[255,0,255]} #Asignamos colores mediante un diccionario
        self.color = 'r' #Empezamos abriendo la ventana con el color determinado rojo
    #Funciones protegidas OpenGL
    def paintGL(self):
        glLoadIdentity()
        glMatrixMode( GL_MODELVIEW )
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glEnable(GL_DEPTH_TEST)
        self.dibujar() #Dibujamos
        glFlush()
    def resizeGL(self, widthInPixels, heightInPixels):
        a,b=widthInPixels, heightInPixels
        glViewport(0, 0, widthInPixels, heightInPixels)
    def initializeGL(self):
        glClearColor(0.0, 0.0, 0.0, 1.0)
        glClearDepth(1.0)
    #Metodos-seleccion
    def dibujar(self): #Dibujamos las figuras correspondientes a lo que nos indique el texto del combo box de figuras
        glColor3fv(self.colores[self.color]) #También le asignamos el color correspondiente al texto del combo box de colores
        if self.figura == 'cuadrado':
            self.cuadrado()
        elif self.figura == 'circulo':
            self.circulo()
        elif self.figura == 'rectangulo':
            self.rectangulo()
        elif self.figura == 'custom':
            self.custom()
        else:
            self.triangulo()
        self.grid() #Dibujamos un plano cartesiano
        self.origin() #Dibujamos el origen
        
    #Metodos-figuras
    def triangulo(self): #Función para dibujar el triángulo
        glBegin(GL_POLYGON) #Empieza el dibujo
        glVertex2f(0.0, 0.5) #Coordenadas
        glVertex2f(0.5, -0.5)
        glVertex2f(-0.5, -0.5)
        glEnd() #Termina el dibujo
    def cuadrado(self): #Función para dibujar el cuadrado
        glBegin(GL_POLYGON)        
        glVertex2f(-0.5, 0.5)
        glVertex2f(0.5, 0.5)
        glVertex2f(0.5, -0.5)
        glVertex2f(-0.5, -0.5)
        glEnd()
    def circulo(self): #Función para dibujar el círculo
        glBegin(GL_POLYGON)
        b=np.arange(0,2*np.pi,(2*np.pi)/30)
        radio=0.5
        for i in b:
            glVertex2f(radio*np.cos(i), radio*np.sin(i))
        glEnd()
    def rectangulo(self): #Función para dibujar el rectángulo
        glBegin(GL_POLYGON)        
        glVertex2f(-0.7, 0.5)
        glVertex2f(0.7, 0.5)
        glVertex2f(0.7, -0.5)
        glVertex2f(-0.7, -0.5)
        glEnd()
                  
    def grid(self): #Función para dibujar plano cartesiano
        # Dibujar línea horizontal
        glColor3fv([0.5, 0.5, 0.5])
        glBegin(GL_LINES)
        glVertex2f(-1, 0)
        glVertex2f(1, 0)
        glEnd()
        
        # Dibujar línea vertical
        glBegin(GL_LINES)
        glVertex2f(0, -1)
        glVertex2f(0, 1)
        glEnd()
        
    def origin(self): #Función para divujar el origen
        glColor3fv([90,27,255])
        glBegin(GL_LINES)
        glVertex2f(-1,0)
        glVertex2f(1,0)
        glVertex2f(0,1)
        glVertex2f(0,-1)
        glEnd()
    

if __name__ == "__main__":
   app = QtWidgets.QApplication(sys.argv)
   ventana = Ventana()
   sys.exit(app.exec_())
