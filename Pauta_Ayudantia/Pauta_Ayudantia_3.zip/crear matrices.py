


print("########################################################################################################################################################################")


fila=int(input("Digito el numero de fila: "))                       # Pedimos el numero de filas que tendra la matriz para su dimension 
columna=int(input("Digite el numero de columnas: "))                # Pedimos el número de columnas que tendra la matriz para su dimesion


matriz=[]                                                           # Variable donde alojaremos la matriz
contador_nulo=0
contador_unos=0
contador_sup=0
contador_inf=0
sumd=0
aux=0

for i in range(fila):                                               # Iniciamos un for que recorrera las filas de la matriz entre 0 y el numero de variable fila que solicitamos en un inicio
    matriz.append([])                                               # Agrega una fila vacia para empezar a llenar por poscicion M i,j
    for j in range(columna):                                        # For que recorrera por columnas en la fila i fijada en el for de arriba
        valor=int(input(f"Digite el valor, en posicion M {i+1}{j+1} de la matriz:"))   # Ingreso de valor en la posicion M i,j
        matriz[i].append(valor)                                     # Agregar en la posicion i con la posicion j el valor ingresado
        if valor ==0:
                contador_nulo+=1  
        if i == j and valor == 1: 
                contador_unos+=1   
        if j<i and valor ==0:
                contador_sup +=1
        if j>i and valor==0:
                contador_inf+=1 
        if i==j:
            sumd=valor+sumd

for i in range(fila):
    aux= aux+i

for i in matriz:                                                    # Eecorre la variable matriz
    print(i, end= ' ')                                              # Muestra la matriz por fila y salta linea
    print()       

if contador_nulo == fila*columna:
    print("MATRIZ ES NULA")

if contador_unos==fila and contador_nulo==(fila*columna)-fila:
    print("MATRIZ IDENTIDAD")

if aux == contador_sup:
    print("ES UNA MATRIZ TRIANGULAR SUPERIOR")

if aux == contador_inf:
    print("ES UNA MATRIZ TRIANGULAR INFERIOR")

print("La traza de la matriz es:", sumd)


print("##################################################################################################################")