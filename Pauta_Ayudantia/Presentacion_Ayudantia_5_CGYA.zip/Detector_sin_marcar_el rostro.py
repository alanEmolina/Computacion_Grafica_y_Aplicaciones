import sys
from PyQt5 import QtCore, QtGui, QtWidgets, uic
from PyQt5.QtCore import pyqtSlot, Qt
import numpy as np
import cv2
import matplotlib.pyplot as plt

class Ventana(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()

        self.ui = uic.loadUi('Ventana.ui')  # Asegúrate de que Ventana.ui exista en el mismo directorio
        self.ui.setWindowTitle("Interfaz Gráfica")
        self.ui.resize(760, 420)
        
        self.ui.setWindowIcon(QtGui.QIcon('uoh.jpg'))
        self.ui.setWindowFlags(Qt.WindowCloseButtonHint | Qt.WindowMinimizeButtonHint)
        self.ui.show()
        
        # Señal de video
        self.cap = None
        self.face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_frontalface_default.xml')
        self.detectar_cara = False

        # Señales del reloj
        self.timer = QtCore.QTimer()  
        self.timer.timeout.connect(self.reloj)
        self.th = 100

        # Señales de los botones
        self.ui.Activar.clicked.connect(self.Comenzar)
        self.ui.Desactivar.clicked.connect(self.Detener)   
        self.ui.comboBox.currentIndexChanged.connect(self.mostrar)
        self.ui.actionSalir.triggered.connect(self.cerrar)

        # Crea una escena para mostrar el histograma en la ventana
        self.scene = QtWidgets.QGraphicsScene()
        self.ui.Histograma.setScene(self.scene)

    def cerrar(self):
        if self.cap:
            self.cap.release()  # Libera la cámara antes de cerrar la aplicación
        self.ui.close()  # Cierra la ventana

    def reloj(self):
        if self.cap is not None:
            ret, frame = self.cap.read()
            if ret and frame.size != 0:
                self.rgb =  cv2.cvtColor(frame, cv2.COLOR_BGR2RGB ) 
                self.gray = cv2.cvtColor(self.rgb, cv2.COLOR_RGB2GRAY)
                self.height, self.width, self.channel = self.rgb.shape
                ret, self.bw = cv2.threshold(self.gray, self.th, 255, cv2.THRESH_BINARY)

                if self.detectar_cara:
                    faces = self.face_cascade.detectMultiScale(self.gray, 1.1, 5, minSize=(30,30), flags=cv2.CASCADE_SCALE_IMAGE)
                    for (x, y, w, h) in faces:
                        cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)
                self.mostrar()

    def mostrar(self):
        if self.ui.comboBox.currentText() == 'RGB' and hasattr(self, 'rgb'):
            
            qim = QtGui.QImage(self.rgb.data, self.width, self.height, 3*self.width, QtGui.QImage.Format_RGB888)
            self.scene.clear()

        elif self.ui.comboBox.currentText() == 'Escala de grises' and hasattr(self, 'gray'): 
            qim = QtGui.QImage(self.gray.data, self.width, self.height, self.width, QtGui.QImage.Format_Indexed8)
            
            self.histograma()
        elif hasattr(self, 'bw'):
            qim = QtGui.QImage(self.bw.data, self.width, self.height, self.width, QtGui.QImage.Format_Indexed8)
            
            self.scene.clear()

        else:
            return
        pix = QtGui.QPixmap.fromImage(qim).scaled(360,270)
        self.ui.pantalla_camara.setPixmap(pix)

    @pyqtSlot()
    def Comenzar(self):
        if self.cap is None or not self.cap.isOpened():
            self.cap = cv2.VideoCapture(0)
        self.detectar_cara = True
        self.ui.Activar.setEnabled(False)
        self.ui.Desactivar.setEnabled(True)
        self.timer.start()  # Inicia el temporizador para capturar frames
        
    @pyqtSlot()
    def Detener(self):
        self.detectar_cara = False
        self.ui.Desactivar.setEnabled(False)
        self.ui.Activar.setEnabled(True)
        self.scene.clear()
        self.ui.pantalla_camara.clear()  # Limpiar el contenido del label
        #self.ui.pantalla_camara.setPixmap(QtGui.QPixmap())  # Establecer un pixmap vacío
        if self.cap is not None:
            self.cap.release()
        
        
    def histograma(self):
        if self.ui.comboBox.currentText() == 'Escala de grises':
            hist = cv2.calcHist([self.gray], [0], None, [256], [0, 256])
            hist_image = self.plot_histogram(hist)
            qim = QtGui.QImage(hist_image.data, hist_image.shape[1], hist_image.shape[0], hist_image.strides[0], QtGui.QImage.Format_RGB888)
            pix = QtGui.QPixmap.fromImage(qim)
            self.scene.clear()  # Limpia la escena antes de agregar una nueva imagen
            self.scene.addPixmap(pix)
        
            

        
    def plot_histogram(self, hist):
        hist = hist.flatten()
        hist_image = np.zeros((256, 256, 3), dtype=np.uint8)
        cv2.normalize(hist, hist, 0, 255, cv2.NORM_MINMAX)
        hist = np.int32(np.around(hist))
        for x, y in enumerate(hist):
            cv2.line(hist_image, (x, 255), (x, 255-y), (255, 0, 0))
        return hist_image

app = QtWidgets.QApplication(sys.argv)
ventana = Ventana()
sys.exit(app.exec_())
